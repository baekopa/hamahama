-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: hamahama
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `meeting`
--

DROP TABLE IF EXISTS `meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting` (
  `created_at` datetime(6) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `meeting_id` bigint NOT NULL AUTO_INCREMENT,
  `modified_at` datetime(6) NOT NULL,
  `study_at` datetime(6) DEFAULT NULL,
  `study_id` bigint NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `note_summary` text,
  `record_file` varchar(255) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`meeting_id`),
  KEY `FK2gdy0hs8o6kb3ewl4ckilubwo` (`study_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting`
--

LOCK TABLES `meeting` WRITE;
/*!40000 ALTER TABLE `meeting` DISABLE KEYS */;
INSERT INTO `meeting` VALUES ('2024-04-03 01:55:32.340658',NULL,1,'2024-04-03 01:55:32.340658','2024-04-03 01:00:00.000000',4,'sumin lee','sumin lee',NULL,'https://p22d105s3.s3.ap-northeast-2.amazonaws.com/record/recording_23d5193d-d462-4357-9178-9d67a94583c9.wav','fsdfasdf'),('2024-04-03 02:40:34.256818',NULL,2,'2024-04-03 02:40:34.256818','2024-04-03 03:40:00.000000',2,'이수민','이수민',NULL,NULL,'dfasd'),('2024-04-03 03:15:14.877610',NULL,3,'2024-04-03 03:15:14.877610','2024-04-03 04:15:00.000000',5,'sumin lee','sumin lee',NULL,NULL,'ㅁㄴㅇㄹ'),('2024-04-03 10:17:44.806791',NULL,4,'2024-04-03 10:18:05.020964','2024-04-25 10:18:00.000000',3,'sumin lee','sumin lee',NULL,'https://p22d105s3.s3.ap-northeast-2.amazonaws.com/record/recording_ca40d76f-c0e4-4722-be7a-90e5953eb04d.wav','asdf'),('2024-04-03 10:22:08.202434',NULL,5,'2024-04-03 10:22:35.936524','2024-04-11 10:23:00.000000',3,'sumin lee','sumin lee',NULL,'https://p22d105s3.s3.ap-northeast-2.amazonaws.com/record/recording_3946b9d5-d8cc-475f-a4c2-dacef00b7048.wav','asdfasdf'),('2024-04-03 14:15:39.611490',NULL,6,'2024-04-03 14:50:00.833123','2024-04-03 15:15:00.000000',3,'sumin lee','sumin lee','네, 이해했습니다. 이제 준비 완료할게요.','https://p22d105s3.s3.ap-northeast-2.amazonaws.com/record/recording_84c4b943-0548-42cc-8ed0-6dfcc9ca681d.wav','asdf'),('2024-04-04 01:29:06.947610',NULL,7,'2024-04-04 01:38:02.869822','2024-04-05 17:00:00.000000',10,'sumin lee','sumin lee',NULL,'https://p22d105s3.s3.ap-northeast-2.amazonaws.com/record/recording_381a2e20-e943-4347-a59d-0a550c85a6c7.wav','네트워크 1차'),('2024-04-04 01:39:14.687084',NULL,8,'2024-04-04 01:49:09.953197','2024-04-05 17:00:00.000000',10,'sumin lee','sumin lee',NULL,'https://p22d105s3.s3.ap-northeast-2.amazonaws.com/record/recording_a1fde778-5fa9-4991-b751-12cbc5449d45.wav','네트워크 1차');
/*!40000 ALTER TABLE `meeting` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:24:27
